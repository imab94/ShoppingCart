from django.contrib import admin
from shopping.models import Category

class ShopingAdmin(admin.ModelAdmin):
    prepopulated_fields = {"slug" :('name',)}
    list_display = ('name','slug')

admin.site.register(Category, ShopingAdmin)

# Register your models here.
